package servidor;

import java.io.*;
import java.net.Socket;

/**
 * Gerencia a conexão de um cliente (aluno)
 * - Recebe o nickname
 * - Notifica entrada e saída
 * - Trata mensagens e comando /quem
 */
public class ClientHandler implements Runnable {

    private final Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private String nickname;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    public String getNickname() {
        return nickname;
    }

    /**
     * Envia uma mensagem para este cliente
     */
    public void enviar(String mensagem) {
        if (out != null) {
            out.println(mensagem);
        }
    }

    @Override
    public void run() {
        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            // Recebe o apelido (nickname)
            nickname = in.readLine();
            if (nickname == null || nickname.trim().isEmpty()) {
                nickname = "Anônimo";
            }

            // Notificação de ENTRADA
            String entrada = "* " + nickname + " entrou na sala *";
            System.out.println(entrada);
            ChatServer.notificarTodos(entrada);

            String linha;
            while ((linha = in.readLine()) != null) {
                linha = linha.trim();

                // Comando de saída
                if (linha.equalsIgnoreCase("sair")) {
                    break;
                }

                // Comando /quem → lista usuários online
                if (linha.equalsIgnoreCase("/quem")) {
                    enviar(ChatServer.listarUsuariosOnline());
                    continue;
                }

                // Mensagem normal no formato: Nome: Texto
                String mensagemFormatada = nickname + ": " + linha;
                System.out.println(mensagemFormatada);
                ChatServer.broadcast(mensagemFormatada, this);
            }

        } catch (IOException e) {
            System.err.println("Erro com cliente " + nickname + ": " + e.getMessage());
        } finally {
            // Notificação de SAÍDA
            if (nickname != null) {
                String saida = "* " + nickname + " saiu da sala *";
                System.out.println(saida);
                ChatServer.notificarTodos(saida);
            }
            ChatServer.removerCliente(this);
            fecharConexao();
        }
    }

    private void fecharConexao() {
        try {
            if (in != null) in.close();
            if (out != null) out.close();
            if (socket != null && !socket.isClosed()) socket.close();
        } catch (IOException e) {
            // silencioso
        }
    }
}
